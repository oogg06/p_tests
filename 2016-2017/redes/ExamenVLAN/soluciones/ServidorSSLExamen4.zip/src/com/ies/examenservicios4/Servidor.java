package com.ies.examenservicios4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;


public class Servidor {
	
	String almacen="/home/usuario/examenes/ExamenServicios4/FicherosExamen/AlmacenClave123456.store";
	String clave="123456";
	int PUERTO_ESCUCHA=9876;
	SSLServerSocket socketServidor;
	public Servidor() throws IOException, NoSuchAlgorithmException{
		
		
		socketServidor=GestorSeguridad.getServerSocketSeguro2(almacen, clave, PUERTO_ESCUCHA);
	}
	public void escuchar() throws IOException{
		BufferedReader entrada;
		PrintWriter salida;
		while (true){
			Socket connRecibida=socketServidor.accept();
			Peticion p=new Peticion(connRecibida);
			Thread hiloAsociado=new Thread(p);
			hiloAsociado.start();
		}
		
	}
	public static void main(String[] args) {
		Servidor servidor;
		try {
			servidor = new Servidor();
			servidor.escuchar();
		} catch (IOException e) {
			System.out.println("No fue posible crear el socket del servidor");
			System.out.println("O fue imposible enviar/recibir datos");
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			System.out.println("El algoritmo de cifrado especificado");
			System.out.println("no es correcto");
			e.printStackTrace();
		}
	}

}
