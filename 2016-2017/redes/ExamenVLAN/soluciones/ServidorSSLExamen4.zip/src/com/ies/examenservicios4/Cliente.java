package com.ies.examenservicios4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public class Cliente {
	/* Recuerdese que en el almacen del cliente debe haberse importado el certificado del servidor*/
	String almacen="/home/usuario/clavescliente";
	String clave="abcdabcd";
	SSLSocket conexion;
	public Cliente(String ip, int puerto) 
			throws UnknownHostException, IOException,
			KeyManagementException, NoSuchAlgorithmException, 
			KeyStoreException{
		
		conexion=GestorSeguridad.getSocketSeguroConfiandoEn(almacen, clave, ip, puerto);
		
	}
	public String getRespuesta(String linea) throws IOException{
		BufferedReader entrada;
		PrintWriter salida;
		entrada=new BufferedReader(new InputStreamReader(conexion.getInputStream()));
		salida=new PrintWriter(new OutputStreamWriter(conexion.getOutputStream()));
		/* De esta linea se intenta averiguar la longitud*/
		salida.println(linea);
		salida.flush();
		/* Si todo va bien, el servidor nos contesta el numero*/
		String lineaDevuelta=entrada.readLine();
		return lineaDevuelta;
	}
	public static void main(String[] args) {
		Cliente c;
		try {
			c = new Cliente("127.0.0.1", 9876);
			String respuesta=c.getRespuesta("HOLA ");
			System.out.println("La respuesta devuelta es:"+respuesta);
		} catch (UnknownHostException e) {
			System.out.println("El host no existe");
			System.out.println("está mal escrito");
			System.out.println("o no funciona");
		} catch (IOException e) {
			System.out.println("No ha sido posible");
			System.out.println("leer/enviar datos");
			e.printStackTrace();
		} catch (KeyManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (KeyStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
