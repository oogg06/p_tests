package com.ies.examenservicios4;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;

public class GestorSeguridad {
	public static KeyStore getAlmacen(String ruta, String clave){
		KeyStore almacen=null;
		try {
			FileInputStream fis=new FileInputStream(ruta);
			almacen=KeyStore.getInstance(KeyStore.getDefaultType());
			almacen.load(fis, clave.toCharArray());
		} catch (FileNotFoundException e) {
			System.out.println("No existe el fichero:"+ruta);
			e.printStackTrace();
		} catch (KeyStoreException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CertificateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return almacen;
	}
	public static SSLContext getContextoSSLconfiandoEn(String ruta, String clave) 
			throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException{
		SSLContext contexto=null;
		TrustManagerFactory fabricaGestoresConfianza=
				TrustManagerFactory.getInstance(
						TrustManagerFactory.getDefaultAlgorithm()
						);
		KeyStore almacen=getAlmacen(ruta, clave);
		fabricaGestoresConfianza.init(almacen);
		contexto=SSLContext.getInstance("TLS");
		contexto.init(null, fabricaGestoresConfianza.getTrustManagers(),null);
		return contexto;
	}
	public static SSLContext getContextoSSL(String ruta, String clave){
		SSLContext contexto=null;
		
		try {
			KeyStore almacen=getAlmacen(ruta, clave);
			KeyManagerFactory fabricaGestoresClaves;
			fabricaGestoresClaves = KeyManagerFactory.getInstance(
					KeyManagerFactory.getDefaultAlgorithm());
			fabricaGestoresClaves.init(almacen,clave.toCharArray());
			contexto=SSLContext.getInstance("TLS");
			contexto.init(fabricaGestoresClaves.getKeyManagers(), null, null);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (UnrecoverableKeyException e) {
			e.printStackTrace();
		} catch (KeyStoreException e) {
			e.printStackTrace();
		} catch (KeyManagementException e) {
			e.printStackTrace();
		}
		return contexto;
	}
	public static SSLServerSocket 
		getServerSocketSeguro2
			(String almacen, String clave, int puerto) 
				throws IOException{
		SSLContext contexto=getContextoSSL(almacen, clave);
		SSLServerSocketFactory fabricaSockets=contexto.getServerSocketFactory();
		SSLServerSocket socket=
				(SSLServerSocket) fabricaSockets.createServerSocket(puerto);
		return socket;
	}
	public static SSLSocket getSocketSeguro2
		(String almacen, String clave, String ip, int puerto)
				throws UnknownHostException, IOException{
		SSLContext contexto=getContextoSSL(almacen, clave);
		SSLSocketFactory fabricaSockets=contexto.getSocketFactory();
		SSLSocket socket=
				(SSLSocket) fabricaSockets.createSocket(ip, puerto);
		return socket;
	}
	public static SSLServerSocket 
		getServerSocketSeguro
			(String almacen, String clave, int puerto) 
					throws IOException{
		SSLServerSocketFactory fabricaSockets=(SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
		SSLServerSocket socket=(SSLServerSocket) fabricaSockets.createServerSocket(puerto);
		return socket;
		
	}
	public static SSLSocket getSocketSeguro
		(String almacen, String clave, String ip, int puerto)
			throws UnknownHostException, IOException{
		SSLSocketFactory fabrica=(SSLSocketFactory) SSLSocketFactory.getDefault();
		SSLSocket conexion=(SSLSocket) fabrica.createSocket(ip, puerto);
		return conexion;
	}
	public static SSLSocket getSocketSeguroConfiandoEn
		(String almacen, String clave, String ip, int puerto)
			throws UnknownHostException, IOException, KeyManagementException, NoSuchAlgorithmException, KeyStoreException{
		SSLContext contexto=getContextoSSLconfiandoEn(almacen, clave);
		SSLSocketFactory fabricaSockets=contexto.getSocketFactory();
		SSLSocket socket=
				(SSLSocket) fabricaSockets.createSocket(ip, puerto);
		return socket;
	}
	
	/** Devuelve una lista de TrustManagers, es decir, objetos que pueden 
	 * gestionar qué material es de confianza
	 * @param rutaAlmacen
	 * @param clave
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws KeyStoreException
	 */
	public static TrustManager[] getFiables(String rutaAlmacen, String clave) 
			throws NoSuchAlgorithmException, KeyStoreException{
		KeyStore almacenClaves=getAlmacen(rutaAlmacen, clave);
		TrustManagerFactory fabricaGestoresConfianza=TrustManagerFactory.getInstance("RSA");
		fabricaGestoresConfianza.init(almacenClaves);
		return fabricaGestoresConfianza.getTrustManagers();
	}
	
	
}
