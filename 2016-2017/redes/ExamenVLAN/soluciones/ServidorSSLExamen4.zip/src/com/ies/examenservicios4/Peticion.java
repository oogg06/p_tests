package com.ies.examenservicios4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;


public class Peticion implements Runnable {
	BufferedReader entrada;
	PrintWriter salida;
	Socket connRecibida;
	public Peticion(Socket conexionRecibida){
		this.connRecibida=conexionRecibida;
	}

	public void run() {
		try {
			entrada=new BufferedReader(new InputStreamReader(connRecibida.getInputStream()));
			salida=new PrintWriter(new OutputStreamWriter(connRecibida.getOutputStream()));
			String linea=entrada.readLine();
			if (linea.equals("HOLA")){
				salida.println("OK");
				salida.flush();
			}
			else {
				salida.print("Error, no has enviado la cadena HOLA.");
				salida.println("Comprueba las mayusculas o los espacios.");
				salida.flush();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
}
